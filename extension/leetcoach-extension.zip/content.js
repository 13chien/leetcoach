console.log(`LeetCoach content script loaded`);function e(e){return e.replace(/^\d+\.\s*/,``).toLowerCase().trim()}var t={problemTitle:e(document.title.replace(` - LeetCode`,``)),problemUrl:window.location.href,startedAt:Date.now(),activityCount:0,hintsUsed:0,runCount:0,submitCount:0,lastResult:``,accepted:!1,lastCodeSnapshot:``,codeChangeCount:0};function n(){let e={...t,endedAt:Date.now(),durationSeconds:Math.round((Date.now()-t.startedAt)/1e3)};chrome.storage.local.set({[`session-${t.startedAt}`]:e}),console.log(`LeetCoach saved session:`,e)}function r(){return document.body.innerText.split(`Example`)[0].slice(0,3e3)}function i(){return Array.from(document.querySelectorAll(`.view-line`)).map(e=>e.textContent??``).join(`
`)}async function a(){let e=i();return(await fetch(`https://leetcoach-ixyj.onrender.com/hint`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({problemTitle:t.problemTitle,problemText:r(),code:e,hintLevel:l+1})})).json()}var o=document.createElement(`style`);o.textContent=`
  #leetcoach-popup {
    position: fixed;
    right: 24px;
    bottom: 80px;
    z-index: 999999;
    width: 360px;
    max-height: 520px;
    overflow-y: auto;
    padding: 16px;
    border-radius: 16px;
    background: #111827;
    color: white;
    font-family: Arial, sans-serif;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
  }

  #leetcoach-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
  }

  #leetcoach-subtitle {
    font-size: 12px;
    color: #9ca3af;
    margin-top: 2px;
  }

  #leetcoach-popup p {
    font-size: 14px;
    margin: 8px 0 12px;
    line-height: 1.5;
  }

  #leetcoach-popup small {
    color: #9ca3af;
    line-height: 1.5;
  }

  #leetcoach-actions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
  }

  #leetcoach-actions button {
    flex: 1;
  }

  #leetcoach-popup button {
    background: #2563eb;
    color: white;
    border: none;
    padding: 10px 12px;
    border-radius: 10px;
    cursor: pointer;
    font-weight: 600;
  }

  #leetcoach-popup button:hover {
    background: #1d4ed8;
  }

  #leetcoach-close-icon {
    background: transparent !important;
    color: #9ca3af !important;
    font-size: 16px;
    padding: 0 !important;
    margin: 0 !important;
  }

  #leetcoach-close-icon:hover {
    color: white !important;
    background: transparent !important;
  }

  #leetcoach-button {
    position: fixed;
    right: 24px;
    bottom: 24px;
    z-index: 999999;
    padding: 10px 14px;
    border-radius: 999px;
    border: none;
    background: #2563eb;
    color: white;
    cursor: pointer;
    font-weight: 700;
    box-shadow: 0 10px 20px rgba(0,0,0,0.25);
  }

  #leetcoach-button:hover {
    background: #1d4ed8;
  }

  #leetcoach-template-box {
    white-space: pre-wrap;
    background: #020617;
    padding: 10px;
    border-radius: 8px;
    overflow: auto;
    max-height: 240px;
    max-width: 100%;
    font-size: 12px;
    line-height: 1.5;
  }
`,document.head.appendChild(o);var s=Date.now(),c=!1,l=0;function u(){let e=document.getElementById(`leetcoach-popup`);e&&e.remove()}function d(){s=Date.now(),c=!1;let e=document.getElementById(`leetcoach-button`);e&&(e.textContent=`💡 Coach`),t.activityCount++,n()}function f(){let e=document.body.innerText.toLowerCase();e.includes(`accepted`)?(t.lastResult=`Accepted`,t.accepted=!0,n()):e.includes(`wrong answer`)?(t.lastResult=`Wrong Answer`,n()):e.includes(`runtime error`)?(t.lastResult=`Runtime Error`,n()):e.includes(`time limit exceeded`)&&(t.lastResult=`Time Limit Exceeded`,n())}function p(){if(document.getElementById(`leetcoach-button`))return;let e=document.createElement(`button`);e.id=`leetcoach-button`,e.textContent=`💡 Coach`,e.addEventListener(`click`,e=>{e.stopPropagation(),document.getElementById(`leetcoach-popup`)?u():m()}),document.body.appendChild(e)}function m(){if(document.getElementById(`leetcoach-popup`))return;let e=document.createElement(`div`);e.id=`leetcoach-popup`,e.innerHTML=`
    <div id="leetcoach-header">
      <div>
        <strong>LeetCoach</strong>

        <div id="leetcoach-subtitle">
          Your coding interview coach
        </div>
      </div>

      <button id="leetcoach-close-icon">
        ✕
      </button>
    </div>

    <p id="leetcoach-text">
      Need help with this problem?
    </p>

    <div id="leetcoach-actions">
      <button id="leetcoach-hint">
        Hint
      </button>

      <button id="leetcoach-scaffold">
        Template
      </button>
    </div>
  `,document.body.appendChild(e);let r=document.getElementById(`leetcoach-hint`),i=document.getElementById(`leetcoach-scaffold`),o=document.getElementById(`leetcoach-close-icon`),s=document.getElementById(`leetcoach-text`);r?.addEventListener(`click`,async e=>{if(e.stopPropagation(),!(!s||!r)){s.textContent=`Generating hint...`;try{let e=await a();s.innerHTML=`
        ${e.hint}

        <br/><br/>

        <small>
          Pattern: ${e.pattern??`Unknown`}<br/>
          Complexity: ${e.complexity??`Unknown`}<br/>
          Source: ${e.source??`unknown`}
        </small>
      `,l++,l>=4?(r.textContent=`No more hints`,r.setAttribute(`disabled`,`true`),r.style.opacity=`0.6`,r.style.cursor=`not-allowed`):r.textContent=`Next Hint`,t.hintsUsed++,n()}catch(e){console.error(`LeetCoach hint error:`,e),s.textContent=`Could not fetch hint.`}}}),i?.addEventListener(`click`,async e=>{if(e.stopPropagation(),s){s.textContent=`Generating template...`;try{let e=(await a()).scaffold||`No template available yet.`;s.innerHTML=`
        <strong>Starter Template</strong>

        <p>
          This gives you a TODO-based structure without revealing the full solution.
        </p>

        <pre id="leetcoach-template-box">${e}</pre>

        <button id="leetcoach-copy-template">
          Copy Template
        </button>
      `,document.getElementById(`leetcoach-copy-template`)?.addEventListener(`click`,async t=>{t.stopPropagation(),await navigator.clipboard.writeText(e);let n=document.getElementById(`leetcoach-copy-template`);n&&(n.textContent=`Copied!`)})}catch(e){console.error(`LeetCoach template error:`,e),s.textContent=`Could not generate template.`}}}),o?.addEventListener(`click`,e=>{e.stopPropagation(),u()})}document.addEventListener(`keydown`,d),document.addEventListener(`click`,e=>{let n=e.target;if(n.closest(`#leetcoach-popup`)||n.closest(`#leetcoach-button`))return;let r=n.innerText?.toLowerCase()??``;r.includes(`run`)&&t.runCount++,r.includes(`submit`)&&t.submitCount++,d(),setTimeout(f,3e3)}),p(),setInterval(()=>{if(Date.now()-s>10*1e3&&!c){c=!0;let e=document.getElementById(`leetcoach-button`);e&&(e.textContent=`Need a hint?`)}},1e3),setInterval(()=>{let e=i();e.trim()&&(t.lastCodeSnapshot&&e!==t.lastCodeSnapshot&&(t.codeChangeCount++,n()),t.lastCodeSnapshot=e)},3e3),window.addEventListener(`beforeunload`,()=>{let e={...t,endedAt:Date.now(),durationSeconds:Math.round((Date.now()-t.startedAt)/1e3)};chrome.storage.local.set({[`session-${t.startedAt}`]:e})});